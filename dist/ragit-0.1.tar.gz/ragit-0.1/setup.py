from setuptools import setup, find_packages

setup(
    name="ragit",
    version="0.1",
    packages=find_packages(),
    install_requires = ['sentence-transformers>=3.4.1', 
                        'pandas>=2.2.3', 'chromadb>=0.6.3', 
                        'setuptools>=75.8.0', 
                        'wheel>=0.45.1', 'twine>=6.1.0']   
)